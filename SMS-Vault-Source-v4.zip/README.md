# SMS Vault — Automatic encrypted SMS backup and read-only conversations

**Source project, not a built or device-tested APK.** Android Java project, Gradle 8.11.1 / Android Gradle Plugin as specified in `settings.gradle`. GitHub Actions builds a debug APK on push or manual workflow dispatch.

- Google Messages-inspired inbox, search, and incoming/outgoing conversation bubbles. No Google branding.
- PIN gate on app open; Android Keystore AES-256-GCM encrypted local file. PIN gate protects UI access but is **not** used to derive the encryption key. PIN hashing uses SHA-256 with salt; this is a basic gate, not hardened against offline attacks. Android Keystore and device encryption protect the vault at rest.
- `SMS_RECEIVED` receiver initiates backup after incoming SMS; `ContentObserver` updates while the app is active; JobScheduler periodic fallback is a best-effort safety net (not immediate). Outgoing SMS changes cannot be guaranteed immediately when another app is the default SMS handler.
- Backup remains in the app after deletion from the default SMS app **if the SMS was already captured**. Reinstalling or clearing app data destroys the encrypted backup. No cloud sync or export.
- Does not back up RCS or MMS. Android restricted SMS permissions can prevent operation on sideloaded builds; no bypasses included. This is for a user's own device and messages with informed consent.
- Backup UI is not surfaced in the conversation list; Android permission requests and settings remain visible. No covert operation or notification suppression.

## Build
Upload the project contents (not the outer ZIP) to a GitHub repository and run `.github/workflows/build.yml`. Download the `SMS-Vault-Backup-APK` workflow artifact. Installation may fail if an older app with the same package ID is signed by another key; do not uninstall an existing copy before safeguarding its data. GitHub debug signing keys are ephemeral between runners, so subsequent builds may not update an existing installation. For stable updates, configure a securely managed release signing key.

## Important limitations
This is an untested source prototype. No guarantee of instant outgoing backup or unrestricted background execution on ColorOS. PIN entry and permissions require explicit user interaction. Android security controls remain enabled.

v4: Single-number-only SMS backup. Explicit enable/stop control, normalized +91/0 phone numbers, encrypted local storage. Only newly read messages matching the selected number are imported. Existing v3 vault records are NOT automatically deleted or filtered. To avoid retaining old all-number backups, uninstall v3 (which deletes its local vault) before installing v4. SMS permissions still required and Play Protect may block installation. Outgoing sync is best-effort while Google Messages remains default.
