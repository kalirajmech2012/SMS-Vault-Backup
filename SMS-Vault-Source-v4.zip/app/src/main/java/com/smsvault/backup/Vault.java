package com.smsvault.backup;
import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.*;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.*;
import org.json.*;

public final class Vault {
 private static final String KEY="sms_vault_local_key";
 private static SecretKey key() throws Exception {
  KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
  if(ks.containsAlias(KEY)) return (SecretKey)ks.getKey(KEY,null);
  KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
  gen.init(new KeyGenParameterSpec.Builder(KEY,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
  return gen.generateKey();
 }
 private static File file(Context c){return new File(c.getFilesDir(),"vault.enc");}
 public static synchronized JSONObject load(Context c) throws Exception {
  File f=file(c); if(!f.exists())return new JSONObject();
  byte[] all=new byte[(int)f.length()];try(FileInputStream in=new FileInputStream(f)){int off=0,n;while(off<all.length&&(n=in.read(all,off,all.length-off))>0)off+=n;if(off!=all.length)throw new IOException("Truncated vault");}
  if(all.length<29)throw new IOException("Invalid vault");
  Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
  cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Arrays.copyOfRange(all,0,12)));
  return new JSONObject(new String(cipher.doFinal(Arrays.copyOfRange(all,12,all.length)),"UTF-8"));
 }
 public static synchronized void save(Context c,JSONObject data) throws Exception {
  byte[] iv=new byte[12];new SecureRandom().nextBytes(iv);
  Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key(),new GCMParameterSpec(128,iv));
  byte[] encrypted=cipher.doFinal(data.toString().getBytes("UTF-8"));
  File tmp=new File(c.getFilesDir(),"vault.tmp");
  try(FileOutputStream out=new FileOutputStream(tmp)){out.write(iv);out.write(encrypted);out.getFD().sync();}
  if(!tmp.renameTo(file(c)))throw new IOException("Unable to save vault");
 }
}
