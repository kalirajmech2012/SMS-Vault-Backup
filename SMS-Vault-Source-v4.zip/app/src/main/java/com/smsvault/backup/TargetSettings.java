package com.smsvault.backup;
import android.content.Context;
import android.content.SharedPreferences;
public final class TargetSettings {
 private static SharedPreferences prefs(Context c){return c.getSharedPreferences("target_settings",Context.MODE_PRIVATE);}
 public static String normalize(String s){
  if(s==null)return "";
  String n=s.replaceAll("[^0-9]","");
  if(n.length()==12 && n.startsWith("91"))n=n.substring(2);
  else if(n.length()==11 && n.startsWith("0"))n=n.substring(1);
  return n;
 }
 public static String target(Context c){return prefs(c).getString("target","");}
 public static boolean enabled(Context c){return prefs(c).getBoolean("enabled",false);}
 public static boolean matches(Context c,String address){
  String t=target(c);
  return enabled(c)&&t.length()==10&&t.equals(normalize(address));
 }
 public static void set(Context c,String number,boolean enabled){
  String n=normalize(number);
  if(n.length()!=10)throw new IllegalArgumentException("Enter a valid 10-digit Indian mobile number");
  prefs(c).edit().putString("target",n).putBoolean("enabled",enabled).apply();
 }
 public static void stop(Context c){prefs(c).edit().putBoolean("enabled",false).apply();}
}
