package com.smsvault.backup;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
public class BackupJob extends JobService {
 public static void schedule(Context c){
  JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
  js.schedule(new JobInfo.Builder(102,new ComponentName(c,BackupJob.class)).setPeriodic(15*60*1000L).setPersisted(false).build());
 }
 @Override public boolean onStartJob(JobParameters p){new Thread(()->{try{SmsBackup.sync(getApplicationContext());}catch(Exception e){android.util.Log.w("SMSVault","Backup skipped: "+e.getClass().getSimpleName());}finally{jobFinished(p,false);}}).start();return true;}
 @Override public boolean onStopJob(JobParameters p){return true;}
}
