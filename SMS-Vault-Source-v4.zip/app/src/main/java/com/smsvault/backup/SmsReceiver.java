package com.smsvault.backup;
import android.content.*;
import android.os.*;
public class SmsReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  if(!"android.provider.Telephony.SMS_RECEIVED".equals(i.getAction()))return;
  PendingResult pending=goAsync();
  new Thread(()->{try{SmsBackup.sync(c.getApplicationContext());}catch(Exception e){android.util.Log.w("SMSVault","Incoming sync deferred",e);}finally{pending.finish();}},"vault-incoming").start();
 }
}
