package com.smsvault.backup;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.security.*;
import java.util.*;

public class MainActivity extends Activity {
 LinearLayout base, list; EditText search; TextView title; String selected=null; boolean unlocked=false;
 Handler handler=new Handler(Looper.getMainLooper()); ContentObserver observer;
 int blue=Color.rgb(23,91,197), ink=Color.rgb(27,37,52);
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);gate();}
 @Override protected void onResume(){super.onResume();if(unlocked){observe();refreshAsync();}}
 @Override protected void onPause(){super.onPause();if(observer!=null){getContentResolver().unregisterContentObserver(observer);observer=null;}}
 void observe(){if(observer!=null||checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED)return;
  observer=new ContentObserver(handler){@Override public void onChange(boolean self){refreshAsync();}};
  getContentResolver().registerContentObserver(Uri.parse("content://sms"),true,observer);
 }
 void refreshAsync(){if(!TargetSettings.enabled(this)||checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED)return;
  new Thread(()->{try{SmsBackup.sync(getApplicationContext());runOnUiThread(()->{if(unlocked)render();});}catch(Exception e){android.util.Log.w("SMSVault","Sync postponed",e);}},"vault-sync").start();}
 String digest(String pin,String salt){try{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] a=md.digest((salt+":"+pin).getBytes("UTF-8"));StringBuilder b=new StringBuilder();for(byte v:a)b.append(String.format(java.util.Locale.US,"%02x",v&255));return b.toString();}catch(Exception e){throw new RuntimeException(e);}}
 void gate(){android.content.SharedPreferences pref=getSharedPreferences("lock",0);boolean first=!pref.contains("hash");
  EditText input=new EditText(this);input.setInputType(18);input.setHint(first?"Create 6+ digit PIN":"Enter vault PIN");
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle(first?"Secure your SMS vault":"Unlock SMS Vault").setMessage("Local encrypted backup. Keep your PIN safe; deleting the app destroys its encryption key.").setView(input).setCancelable(false).setPositiveButton(first?"Create":"Unlock",null).setNegativeButton("Exit",(d,w)->finish()).create();
  dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{String pin=input.getText().toString();if(first){if(pin.length()<6){input.setError("Use at least 6 digits");return;}byte[] random=new byte[16];new SecureRandom().nextBytes(random);String salt=android.util.Base64.encodeToString(random,2);pref.edit().putString("salt",salt).putString("hash",digest(pin,salt)).apply();}else if(!digest(pin,pref.getString("salt","")).equals(pref.getString("hash",""))){input.setError("Incorrect PIN");return;}unlocked=true;dialog.dismiss();home();if(TargetSettings.enabled(this)){if(checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS},41);else{BackupJob.schedule(this);observe();refreshAsync();}}}));dialog.show();}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==41){if(TargetSettings.enabled(this)&&checkSelfPermission(Manifest.permission.READ_SMS)==PackageManager.PERMISSION_GRANTED){BackupJob.schedule(this);observe();refreshAsync();}else new AlertDialog.Builder(this).setMessage("SMS permission is needed for automatic backup. Android may restrict this permission for sideloaded apps; use your device's official permission controls.").setPositiveButton("OK",null).show();}}
 void configureTarget(){
  LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(28,8,28,8);
  EditText number=new EditText(this);number.setInputType(3);number.setSingleLine(true);
  number.setHint("10-digit mobile number");number.setText(TargetSettings.target(this));
  layout.addView(number);
  CheckBox consent=new CheckBox(this);
  consent.setText("I consent to locally back up SMS involving this number. SMS access is sensitive; Google Messages remains my default.");
  consent.setChecked(TargetSettings.enabled(this));layout.addView(consent);
  new AlertDialog.Builder(this).setTitle("Single-number backup settings").setView(layout)
   .setPositiveButton("Save",(d,w)->{
      try{
       if(consent.isChecked()){
        TargetSettings.set(this,number.getText().toString(),true);
        if(checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED)
         requestPermissions(new String[]{Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS},41);
        else{BackupJob.schedule(this);refreshAsync();}
       }else TargetSettings.stop(this);
       home();
      }catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
   }).setNeutralButton("Stop backup",(d,w)->{TargetSettings.stop(this);home();})
   .setNegativeButton("Cancel",null).show();
 }
 TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(18,14,18,14);return t;}
 void shell(String heading){base=new LinearLayout(this);base.setOrientation(1);base.setBackgroundColor(Color.WHITE);setContentView(base);title=text(heading,25,ink);title.setTypeface(null,Typeface.BOLD);base.addView(title);}
 void home(){selected=null;shell("Messages");
  TextView settings=text("Backup settings  •  "+(TargetSettings.enabled(this)?"ON":"OFF"),16,blue);
  base.addView(settings);settings.setOnClickListener(v->configureTarget());
  if(!TargetSettings.enabled(this))base.addView(text("Backup is OFF. Select one number and explicitly enable backup in settings.",14,0xff666666));
search=new EditText(this);search.setSingleLine(true);search.setHint("Search messages");search.setPadding(24,12,24,12);base.addView(search);ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(1);sc.addView(list);base.addView(sc,new LinearLayout.LayoutParams(-1,0,1));search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render();}public void afterTextChanged(Editable e){}});render();}
 void render(){if(!unlocked||list==null)return;list.removeAllViews();try{JSONObject vault=Vault.load(this);Map<String,ArrayList<JSONObject>> groups=new HashMap<>();Iterator<String> it=vault.keys();while(it.hasNext()){JSONObject o=vault.getJSONObject(it.next());String address=o.optString("address","Unknown");if(!groups.containsKey(address))groups.put(address,new ArrayList<>());groups.get(address).add(o);}ArrayList<String> names=new ArrayList<>(groups.keySet());Collections.sort(names,(a,b)->Long.compare(latest(groups.get(b)),latest(groups.get(a))));String filter=search==null?"":search.getText().toString().toLowerCase(Locale.ROOT);for(String name:names){ArrayList<JSONObject> msgs=groups.get(name);Collections.sort(msgs,(a,b)->Long.compare(a.optLong("date"),b.optLong("date")));JSONObject last=msgs.get(msgs.size()-1);boolean found=name.toLowerCase(Locale.ROOT).contains(filter);for(JSONObject m:msgs)if(m.optString("body").toLowerCase(Locale.ROOT).contains(filter))found=true;if(!found)continue;TextView row=text("●  "+name+"\n     "+last.optString("body"),17,ink);row.setMaxLines(3);row.setOnClickListener(v->thread(name));list.addView(row);View line=new View(this);line.setBackgroundColor(0xffeeeeee);list.addView(line,new LinearLayout.LayoutParams(-1,1));}if(names.isEmpty())list.addView(text("No backed-up SMS yet. Grant SMS access to begin automatic backup.",16,0xff666666));}catch(Exception e){list.addView(text("Unable to open encrypted vault: "+e.getClass().getSimpleName(),16,Color.RED));}}
 long latest(ArrayList<JSONObject> a){long n=0;for(JSONObject o:a)n=Math.max(n,o.optLong("date"));return n;}
 void thread(String address){selected=address;shell(address);TextView back=text("‹  All conversations",16,blue);base.addView(back);back.setOnClickListener(v->home());ScrollView sc=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(1);content.setPadding(10,8,10,8);sc.addView(content);base.addView(sc,new LinearLayout.LayoutParams(-1,0,1));try{JSONObject vault=Vault.load(this);ArrayList<JSONObject> msgs=new ArrayList<>();Iterator<String> keys=vault.keys();while(keys.hasNext()){JSONObject m=vault.getJSONObject(keys.next());if(address.equals(m.optString("address")))msgs.add(m);}Collections.sort(msgs,(a,b)->Long.compare(a.optLong("date"),b.optLong("date")));for(JSONObject m:msgs){boolean sent=m.optInt("type")==2;TextView bubble=text(m.optString("body")+"\n"+new java.text.SimpleDateFormat("dd MMM, HH:mm",Locale.getDefault()).format(new Date(m.optLong("date"))),16,sent?Color.WHITE:ink);bubble.setBackgroundColor(sent?blue:0xffeef0f3);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.gravity=sent?Gravity.RIGHT:Gravity.LEFT;lp.setMargins(sent?60:4,5,sent?4:60,5);content.addView(bubble,lp);}sc.post(()->sc.fullScroll(View.FOCUS_DOWN));}catch(Exception e){content.addView(text("Cannot read vault",16,Color.RED));}TextView footer=text("Read-only backup • Send messages using your default SMS app",13,0xff666666);base.addView(footer);}
 @Override public void onBackPressed(){if(selected!=null)home();else super.onBackPressed();}
}
