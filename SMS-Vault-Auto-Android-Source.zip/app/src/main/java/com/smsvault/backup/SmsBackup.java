package com.smsvault.backup;
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import org.json.*;
public final class SmsBackup {
 public static synchronized int sync(Context context) throws Exception {
  if(context.checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED)throw new SecurityException("READ_SMS permission not granted");
  JSONObject data=Vault.load(context);int added=0;
  // Android SMS provider includes inbox (type 1) and sent (type 2) messages.
  try(Cursor cur=context.getContentResolver().query(Uri.parse("content://sms"),new String[]{"_id","address","body","date","type"},null,null,"date ASC")){
   if(cur==null)throw new IllegalStateException("SMS provider unavailable");
   while(cur.moveToNext()){
    int type=cur.getInt(4);if(type!=1&&type!=2)continue;
    String id=type+":"+cur.getLong(0);if(data.has(id))continue;
    JSONObject row=new JSONObject();row.put("address",cur.getString(1));row.put("body",cur.getString(2));row.put("date",cur.getLong(3));row.put("type",type);
    data.put(id,row);added++;
   }
  }
  if(added>0)Vault.save(context,data);
  return added;
 }
}
