package com.example.smsvault;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(36,48,36,24);
        status = new TextView(this); status.setTextSize(18);
        Button check = new Button(this); check.setText("Check SMS permission");
        Button request = new Button(this); request.setText("Request SMS permission");
        root.addView(status); root.addView(check); root.addView(request);
        setContentView(root);
        check.setOnClickListener(v -> refresh());
        request.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.READ_SMS}, 1));
        refresh();
    }
    private void refresh() {
        boolean granted = checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
        status.setText("READ_SMS permission: " + (granted ? "GRANTED" : "NOT GRANTED") + "\nNo SMS data is read, saved, or transmitted by this test app.");
    }
    @Override public void onRequestPermissionsResult(int code, String[] p, int[] results) {
        super.onRequestPermissionsResult(code,p,results); refresh();
    }
}
