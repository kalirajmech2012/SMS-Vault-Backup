# SMS Vault Permission Check (prototype)

This is a **permission test only**, not an SMS backup app. It does not read or store messages. It checks whether the OPPO K13 / ColorOS 16 permits `READ_SMS` for this user-installed APK.

## Build using GitHub on Android phone
1. Create a **private** GitHub repository.
2. Upload all files, including `.github/workflows/android.yml` (keep directories intact).
3. Open repository > Actions > Build Android APK > Run workflow (or push to trigger).
4. Download `sms-vault-permission-check-apk` artifact, unzip and install APK.
5. Open app, tap Request SMS permission, then Check SMS permission.
6. If blocked or not granted, do not bypass security restrictions. We will use a user-initiated backup/export approach instead.

Android restricts SMS permissions. This prototype does not establish that automatic backup will be allowed. Do not upload any real SMS content to GitHub.
